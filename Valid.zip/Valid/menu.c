#include "source.h"
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

void splashing(SDL_Surface *splashscreen,SDL_Surface *splash[])
{
	int i=0;
      
     



	SDL_Rect posbackground;

	posbackground.x=0;
	posbackground.y=0;
	while(1)
{
        SDL_BlitSurface(splash[i],NULL,splashscreen,&posbackground);
        SDL_Flip(splashscreen);
        SDL_Delay(500);
        SDL_BlitSurface(NULL,NULL,splashscreen,&posbackground);
        i++;
        if (i == 4){
        i = 0;
        }
        
      }
}
void initBackground(Image *Backg)
{
Backg->img = IMG_Load("IMG/LUNG.png");
 if (Backg->img == NULL) {
printf("Unable to load bitmap: %s\n", SDL_GetError()); 
return;}
Backg->pos1.x = 0;
Backg->pos1.y = 0;
Backg->pos2.x = 0;
Backg->pos2.y = 0;
}
void afficher(Image p,SDL_Surface *ecran)
{
SDL_BlitSurface(p.img,&p.pos2,ecran,&p.pos1);
}
void menu(SDL_Surface *ecran)
{
SDL_Surface *background = NULL,*playy = NULL, *settings = NULL , *quit = NULL;
SDL_Rect positionbackground,positionplay,positionsettings,positionquit,positionClic,positionalpha;
SDL_Event event;

int continuer = 1 ,x = 1 ,y = 1;
background = IMG_Load("IMG/LUNG.png");
positionbackground.x = 0;
positionbackground.y = 0;

SDL_BlitSurface(background, NULL, ecran, &positionbackground);
        SDL_Flip(ecran);
    
    SDL_Quit();





        SDL_Flip(ecran);
    
    SDL_FreeSurface(background);


    SDL_Quit();


}
/*
SDL_Surface* screen;
SDL_Surface* background;
SDL_Rect bg_rect;
int scroll_speed = 1; 
int scroll_direction = 1; 

void loadBackground() {
    background = IMG_Load("IMG/LUNG.png");
    bg_rect.x = 0;
    bg_rect.y = 0;
    bg_rect.w = background->w;
    bg_rect.h = background->h;
}

void scrollBackground() {
    bg_rect.x += scroll_speed * scroll_direction;
    if (bg_rect.x >= background->w) {
        bg_rect.x = 0;
    }
}

void render() {
    SDL_BlitSurface(background, &bg_rect, screen, NULL);
    SDL_Flip(screen);
}

}*/



			

