#include "source.h"
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
int main (int argc,char** argv)
{
SDL_Init(SDL_INIT_AUDIO);
Mix_Init(MIX_INIT_MP3);
SDL_Surface *ecran = NULL;
SDL_Init(SDL_INIT_VIDEO);
SDL_WM_SetIcon(IMG_Load("icon.png"), NULL);
int continuee=1;
int o=0;
Image p;
int frequency = 44100;
    Uint16 format = AUDIO_S16SYS;
    int channels = 2;
    int chunkSize = 2048;
    if (Mix_OpenAudio(frequency, format, channels, chunkSize) < 0) {
        printf("SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError());
        return 1;
    }
    Mix_Music* music = Mix_LoadMUS("hope.mp3");
    if (!music) {
        printf("Failed to load music! SDL_mixer Error: %s\n", Mix_GetError());
        return 1;
    }         
    Mix_PlayMusic(music, -1);  
    /*loadBackground();
    while (true) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                SDL_Quit();
                return 0;
            }
        }
        scrollBackground();
        render();*/


//animation
SDL_Surface *splashscreen;
SDL_Surface *splash[4];
splashscreen=SDL_SetVideoMode(1920,1057,32,SDL_HWSURFACE|SDL_DOUBLEBUF);

splash[0]=IMG_Load("LUNG.png");
splash[1]=IMG_Load("LUNG2.png");
splash[2]=IMG_Load("LUNG3.png");





splashing(splashscreen,splash);

ecran = SDL_SetVideoMode(1920,1057,32, SDL_HWSURFACE | SDL_DOUBLEBUF);
SDL_WM_SetCaption("Hope", NULL);
SDL_Event event;
afficher(p,ecran);
SDL_Flip(ecran);
if (ecran==NULL)
{
printf("error: %s ",SDL_GetError());
exit(EXIT_FAILURE);
}


Mix_FreeMusic(music);
Mix_CloseAudio();
SDL_FreeSurface(ecran);
SDL_Quit();
return EXIT_SUCCESS;
}

