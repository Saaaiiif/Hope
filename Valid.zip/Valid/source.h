#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>

struct Image
{
SDL_Rect pos1;
SDL_Rect pos2;
SDL_Surface * img;
};

typedef struct Image Image;

void splashing(SDL_Surface *splashscreen,SDL_Surface *splash[]);
void initBackground(Image *Backg);
void afficher(Image p,SDL_Surface *ecran);
void menu(SDL_Surface *ecran);
//void scrollBackground();
//void render();

#endif /* MENU_H_ */
